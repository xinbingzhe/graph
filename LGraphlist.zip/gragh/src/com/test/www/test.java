package com.test.www;

import java.util.LinkedList;
import java.util.List;

import com.adjacencuList.www.ArcNode;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<ArcNode> lList = new LinkedList<>();//list��һ���ӿڣ����Ҫ�����µĿռ�Ļ�����Ҫ��һ��ʵ�ֵ�����LinkedList��ArrayList
		ArcNode a = new ArcNode();
		ArcNode b = new ArcNode();
		ArcNode c = new ArcNode();
		a.data=0;
		b.data=1;
		c.data=2;
		lList.add(a);
		lList.add(b);
		lList.add(c);
	    for (ArcNode str: lList) {  
	        System.out.println(str.data);  
	      }  
	    lList.remove(0);
	    lList.remove(b);
	    for (ArcNode str: lList) {  
	        System.out.println(str.data);  
	      }  
	}

}
