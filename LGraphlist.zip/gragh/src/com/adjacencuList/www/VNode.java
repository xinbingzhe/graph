package com.adjacencuList.www;
import java.util.*;
import java.util.ArrayList;

public class VNode {
	public int data;
	List<ArcNode> head1 = new LinkedList<>();
	List<ArcNode> head2 = new LinkedList<>();
}
