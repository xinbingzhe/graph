package com.adjacencuList.www;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class LGraph {
	VNode vertex[];
	public int arcnum,vexnum;//��������������
	public LGraph() {
		vertex = new VNode[100];
		// TODO Auto-generated constructor stub
	}
		public void CreateLGraph() {
			ArcNode pi;
			int v1 = 0,v2 = 0;
			Scanner in = new Scanner(System.in);
			System.out.println("please enter arcnum: ");
			arcnum = in.nextInt();
			System.out.println("please enter vexnum: ");
			vexnum = in.nextInt();
			System.out.println("output arcnum: "+arcnum+"vexnum"+vexnum);
		    //VNode 
			//LGraph lG = new LGraph();
			for(int i=0;i<this.arcnum;i++){
				System.out.println("please enter arcnode: ");
				v1=in.nextInt();
				v2=in.nextInt();
				if(v1 == 0||v2 == 0)break;
				v1--;
				v2--;
				System.out.println("v1:"+v1+" v2:"+v2);
				pi = new ArcNode();
				pi.data = v2;
				this.vertex[v1].head1.add(pi);
				pi = new ArcNode();
				pi.data = v1;
				this.vertex[v2].head2.add(pi);
			}
		}
		public void outputArcNode(LGraph lg){
			//�����forѭ�������ڽӱ�
			for(int i=0;i<lg.vertex.length;i++){
				System.out.println("output lg.vertex["+i+"]: "+lg.vertex[i].data);
				System.out.println("output lg.vertex["+i+"]");
				/*for(Iterator x = lg.vertex[i].head1.iterator();x.hasNext(); ){
					int o =  (Integer)x.next();
					System.out.println();
					}*/
				//��������߽ڵ�
				System.out.println("lg.vertex[i].head1");
			    for (ArcNode arc: lg.vertex[i].head1) {  
			        System.out.println(arc.data);  
			      }  
			    System.out.println("lg.vertex[i].head2");
			    for (ArcNode arc: lg.vertex[i].head2) {  
			        System.out.println(arc.data);  
			      }  
			}
		}
		
		public void DeleteLGgraph(LGraph lg) {
			//ɾ��ͼ�ı߽ڵ㺯��
			//���ѭ�������ڽӱ�
			
			for(int i=0;i<lg.vertex.length;i++){
				System.out.println("output lg.vertex["+i+"]: "+lg.vertex[i].data);
				System.out.println("output lg.vertex["+i+"]");
				//��������߽ڵ�
				System.out.println("remove lg.vertex[i].head1");
			    for (int num1=0;num1<lg.vertex[i].head1.size();num1++) {  
			    	lg.vertex[i].head1.remove(num1);
			      }  
			    System.out.println("remove lg.vertex[i].head2");
			    for (int num=0;num<lg.vertex[i].head2.size();num++) {  
			    	lg.vertex[i].head1.remove(num);
			      }  
			}
		}
	
}
